# BNI Pitch App

Generador automático de presentaciones semanales para miembros BNI.

## Cómo usar
1. Configura `.env` con tu conexión MongoDB.
2. Ejecuta `streamlit run app.py`.
3. Disfruta generando tus presentaciones.

Desarrollado por Fernando con ❤️ y IA.